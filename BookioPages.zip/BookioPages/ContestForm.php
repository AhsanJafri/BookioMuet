<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
    <script src="sweetalert2.all.min.js"></script>
    <!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
    <script src="https://cdn.jsdelivr.net/npm/promise-polyfill"></script>
    <script src="sweetalert2.min.js"></script>
<link rel="stylesheet" href="sweetalert2.min.css">
</head>
<body bgcolor="">

    <div class="main">
        <div class="imgb">
            <img src="images\Bookio Transparent logo.png" class="responsive" style="margin-left:50px; height: 70px;width: 210px;margin-top: 7px;">
        </div>
        
        <div class="container">
            <div class="sign-up-content">
                <form method="POST" class="signup-form" enctype="multipart/form-data">

                <div class="head"><img src="images\form.png" class="responsive" width="20%" style=" margin-left: 30px;
                padding-bottom: 20px;padding-bottom: 50px;"></div>

                 <div class="form-row">
                  <div class="col-1">
                    <label>Name</label>
                  </div>
                  <div class="col-4">
                    <input type="text" name="name" width="100%" required>
                  </div>
                  <div class="col" align="center">
                    <label>&nbspContact No</label>
                  </div>
                  <div class="col">
                    <input type="text" name="contact" required>
                  </div>
                  </div>

<BR>
                 <div class="form-row">
                  <div class="col-1">
                    <label>City</label>
                  </div>
                  <div class="col-4">
                    <input type="text" name="city" width="100%" required>
                  </div>
                  <div class="col" align="center">
                    <label>Email</label>
                  </div>
                  <div class="col">
                    <input type="text" name="email" required>
                  </div>  
                  </div>

<BR>             <div class="form-row">
                  <div class="col-1">
                    <label>Address</label>
                  </div>
                  <div class="col">
                    <input type="text" name="address" width="100%" required>
                  </div>
                  </div>
                  
                  <BR><BR><div class="form-row">
                  <div class="col-1">
                    <label>File</label>
                  </div>
                  <div class="col">
                    <input type="file" name="file" width="100%" required>
                  </div>
                  </div>
                  


                                 <BR><BR><div class="form-textbox">
                        <center><input type="submit" name="submit"  id="submit" class="submit" value="Continue"/>
                      </center>

                </form>

                
            </div>
        </div>

    </div>
</body>
</html>


<?php
  $msg="";
  $conn=mysqli_connect('localhost','root','','Bookio');
  if(isset($_POST['submit'])){
  $target="C:/xampp/htdocs/BookioPages/docs/".basename($_FILES['file']['name']);
  $image=$_FILES['file']['name'];
  $name=$_POST['name'];
  $contact=$_POST['contact'];
  $address=$_POST['address'];
  $email=$_POST['email'];
  $city=$_POST['city'];
  
  $query=mysqli_query($conn,"Insert into writing_contest(Name,Email,Contact,Address,City,File) values('$name','$email','$contact','$address','$city','$image')");
  if($query){
    if(move_uploaded_file($_FILES['file']['tmp_name'],$target)){
      echo "<script>Swal.fire(
      'Good job!',
      'Successfully Submitted!',
      'success')</script>"; 
    }
   } 

  else

    echo "<script>Swal.fire({
  type: 'error',
  title: 'Oops...',
  text: 'Something went wrong!',
  footer: '<a href>Why do I have this issue?</a>'
  })</script>";
  }

?>